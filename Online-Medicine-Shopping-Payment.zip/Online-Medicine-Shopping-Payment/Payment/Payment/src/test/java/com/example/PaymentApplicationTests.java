package com.example;
/*
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/

import com.example.Controller.PaymentController;
import com.example.DTO.PaymentDTO;
import com.example.Entities.Payment;
import com.example.Entities.PaymentStatus;
import com.example.Service.PaymentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class PaymentApplicationTests {

	@Mock
	private PaymentService paymentService;

	@InjectMocks
	private PaymentController paymentController;

	private MockMvc mockMvc;

	private PaymentDTO paymentDTO;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(paymentController).build();

		paymentDTO = new PaymentDTO();
		paymentDTO.setAmount(100.0);
		paymentDTO.setPaymentMethod("CREDIT_CARD");
	}

	@Test
	public void testCreateOrUpdatePayment() throws Exception {
		// Arrange
		Payment payment = new Payment();
		payment.setAmount(paymentDTO.getAmount());
		payment.setPaymentMethod(paymentDTO.getPaymentMethod());
		payment.setPaymentStatus(PaymentStatus.SUCCESS);

		when(paymentService.saveOrUpdatePayment(Mockito.any(PaymentDTO.class))).thenReturn(payment);

		// Act & Assert
		mockMvc.perform(MockMvcRequestBuilders.post("/api/payments/create")
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"amount\":100.0,\"paymentMethod\":\"CREDIT_CARD\"}"))
				.andExpect(status().isCreated())
				.andExpect(MockMvcResultMatchers.jsonPath("$.amount").value(100.0))
				.andExpect(MockMvcResultMatchers.jsonPath("$.paymentMethod").value("CREDIT_CARD"))
				.andExpect(MockMvcResultMatchers.jsonPath("$.paymentStatus").value("SUCCESS"));
	}

	@Test
	public void testGetAllPayments() throws Exception {
		// Arrange
		Payment payment1 = new Payment();
		payment1.setAmount(100.0);
		payment1.setPaymentMethod("CREDIT_CARD");
		payment1.setPaymentStatus(PaymentStatus.SUCCESS);

		Payment payment2 = new Payment();
		payment2.setAmount(150.0);
		payment2.setPaymentMethod("DEBIT_CARD");
		payment2.setPaymentStatus(PaymentStatus.SUCCESS);

		when(paymentService.getAllPayments()).thenReturn(List.of(payment1, payment2));

		// Act & Assert
		mockMvc.perform(MockMvcRequestBuilders.get("/api/payments"))
				.andExpect(status().isOk())
				.andExpect(MockMvcResultMatchers.jsonPath("$.size()").value(2));
	}
	@Test
	public void testDeletePayment() throws Exception {
		// Arrange
		Long paymentId = 1L;

		// Act & Assert
		mockMvc.perform(MockMvcRequestBuilders.delete("/api/payments/{paymentId}", paymentId))
				.andExpect(status().isNoContent());
	}
}
