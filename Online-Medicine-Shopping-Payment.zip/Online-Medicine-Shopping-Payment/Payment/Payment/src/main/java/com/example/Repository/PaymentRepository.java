package com.example.Repository;

import com.example.Entities.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {

    // Find payments by customerId (assuming customer ID exists in the Payment entity)
    //List<Payment> findByCustomerId(Long customerId);

    // Find payment by payment status
    List<Payment> findByPaymentStatus(String paymentStatus);

    // Find a specific payment by its paymentId
    Optional<Payment> findById(Long paymentId);
}