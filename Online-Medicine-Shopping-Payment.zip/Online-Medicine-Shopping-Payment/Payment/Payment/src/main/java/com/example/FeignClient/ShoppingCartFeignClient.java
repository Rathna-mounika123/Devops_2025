package com.example.FeignClient;

import com.example.DTO.ShoppingCartDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "shopping-cart-service", url = "http://localhost:8090/api/shopping-cart")  // Replace the URL with the actual ShoppingCart service URL
public interface ShoppingCartFeignClient {

    // Fetch a ShoppingCart by cartId
    @GetMapping("/{cartId}")
    ShoppingCartDTO getShoppingCartById(@PathVariable("cartId") long cartId);
}
