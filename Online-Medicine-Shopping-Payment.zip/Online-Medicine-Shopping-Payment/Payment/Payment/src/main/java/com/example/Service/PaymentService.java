package com.example.Service;
/*
import com.example.DTO.PaymentDTO;
import com.example.Entities.Payment;
import com.example.Entities.PaymentStatus;
import com.example.Repository.PaymentRepository;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.util.List;
import java.util.Optional;

@Service
@Validated // Ensures that validations are triggered for DTOs
public class PaymentService {

    private final PaymentRepository paymentRepository;

    @Autowired
    public PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }
    public Payment saveOrUpdatePayment(@Valid PaymentDTO paymentDTO) {
        // Convert PaymentDTO to Payment Entity
        Payment payment = new Payment();
        payment.setAmount(paymentDTO.getAmount());
        payment.setPaymentMethod(paymentDTO.getPaymentMethod());

        // Always set paymentStatus to "SUCCESS"
        payment.setPaymentStatus(PaymentStatus.SUCCESS);

        //  payment.setPaymentDate(paymentDTO.getPaymentDate()); // If you want to set the date from the DTO, uncomment this

        // payment.setCustomer(new Customer(paymentDTO.getCustomerId())); // Assuming a constructor or method to set the Customer

        return paymentRepository.save(payment);
    }


    // Get all Payments
    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    // Get Payments by customerId
//    public List<Payment> getPaymentsByCustomerId(Long customerId) {
//        return paymentRepository.findByCustomerId(customerId);
//    }

    // Get a Payment by paymentId
    public Optional<Payment> getPaymentById(Long paymentId) {
        return paymentRepository.findById(paymentId);
    }

    // Get Payments by payment status
    public List<Payment> getPaymentsByStatus(PaymentStatus status) {
        return paymentRepository.findByPaymentStatus(status.name());
    }

    // Delete Payment by paymentId
    public void deletePayment(Long paymentId) {
        paymentRepository.deleteById(paymentId);
    }
}
 */



import com.example.DTO.PaymentDTO;
import com.example.Entities.Payment;
import com.example.Entities.PaymentStatus;
import com.example.Repository.PaymentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.util.List;
import java.util.Optional;

@Service
@Validated
public class PaymentService {

    private static final Logger logger = LoggerFactory.getLogger(PaymentService.class); // Logger setup

    private final PaymentRepository paymentRepository;

    @Autowired
    public PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    public Payment saveOrUpdatePayment(PaymentDTO paymentDTO) {
        logger.info("Received paymentDTO: {}", paymentDTO);

        // Convert PaymentDTO to Payment Entity
        Payment payment = new Payment();
        payment.setAmount(paymentDTO.getAmount());
        payment.setPaymentMethod(paymentDTO.getPaymentMethod());

        // Always set paymentStatus to "SUCCESS"
        payment.setPaymentStatus(PaymentStatus.SUCCESS);

        // Log the payment details before saving
        logger.info("Saving payment with amount: {} and method: {}", payment.getAmount(), payment.getPaymentMethod());

        Payment savedPayment = paymentRepository.save(payment);
        logger.info("Payment saved successfully with ID: {}", savedPayment.getPaymentId());
        return savedPayment;
    }

    // Get all Payments
    public List<Payment> getAllPayments() {
        logger.info("Fetching all payments from repository");
        List<Payment> payments = paymentRepository.findAll();
        logger.info("Retrieved {} payments", payments.size());
        return payments;
    }

    // Get a Payment by paymentId
    public Optional<Payment> getPaymentById(Long paymentId) {
        logger.info("Fetching payment with ID: {}", paymentId);
        Optional<Payment> payment = paymentRepository.findById(paymentId);
        if (payment.isPresent()) {
            logger.info("Payment found with ID: {}", paymentId);
        } else {
            logger.error("Payment not found for ID: {}", paymentId);
        }
        return payment;
    }

    // Get Payments by payment status
    public List<Payment> getPaymentsByStatus(PaymentStatus status) {
        logger.info("Fetching payments with status: {}", status);
        List<Payment> payments = paymentRepository.findByPaymentStatus(status.name());
        logger.info("Retrieved {} payments with status: {}", payments.size(), status);
        return payments;
    }

    // Delete Payment by paymentId
    public void deletePayment(Long paymentId) {
        logger.info("Deleting payment with ID: {}", paymentId);
        paymentRepository.deleteById(paymentId);
        logger.info("Payment with ID: {} deleted successfully", paymentId);
    }
}
