package com.example.Controller;
/*
import com.example.DTO.PaymentDTO;
import com.example.Entities.Payment;
import com.example.Entities.PaymentStatus;
import com.example.Exceptions.PaymentNotFoundException;
import com.example.Service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController      //handling HTTP requests and returning responses in a format like JSON or XML.
@RequestMapping("/api/payments")
@Validated // Ensures that validations are triggered for DTOs
public class PaymentController {

    private final PaymentService paymentService;

    @Autowired
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    // Create or update a Payment
    @PostMapping("/create")
    public ResponseEntity<?> createOrUpdatePayment(@Valid @RequestBody PaymentDTO paymentDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            List<String> errorMessages = bindingResult.getAllErrors().stream()
                    .map(error -> error.getDefaultMessage())
                    .collect(Collectors.toList());
            return new ResponseEntity<>(errorMessages, HttpStatus.BAD_REQUEST);
        }
        Payment savedPayment = paymentService.saveOrUpdatePayment(paymentDTO);
        return new ResponseEntity<>(savedPayment, HttpStatus.CREATED);
    }


    // Get all Payments
    @GetMapping
    public ResponseEntity<List<Payment>> getAllPayments() {
        List<Payment> payments = paymentService.getAllPayments();
        return new ResponseEntity<>(payments, HttpStatus.OK);
    }

    // Get Payment by paymentId
    @GetMapping("/{paymentId}")
    public ResponseEntity<Payment> getPaymentById(@PathVariable Long paymentId) {
        Optional<Payment> payment = paymentService.getPaymentById(paymentId);
        if (payment.isEmpty()) {
            throw new PaymentNotFoundException("No details found on paymentId: " + paymentId);
        }
        return new ResponseEntity<>(payment.get(), HttpStatus.OK);
    }

    // Get Payments by Payment Status
    @GetMapping("/status/{status}")
    public ResponseEntity<List<Payment>> getPaymentsByStatus(@PathVariable String status) {
        PaymentStatus paymentStatus = PaymentStatus.valueOf(status.toUpperCase());
        List<Payment> payments = paymentService.getPaymentsByStatus(paymentStatus);
        return new ResponseEntity<>(payments, HttpStatus.OK);
    }

    // Delete Payment by paymentId
    @DeleteMapping("/{paymentId}")
    public ResponseEntity<Void> deletePayment(@PathVariable Long paymentId) {
        paymentService.deletePayment(paymentId);
        return ResponseEntity.noContent().build();
    }
}
*/



import com.example.DTO.PaymentDTO;
import com.example.Entities.Payment;
import com.example.Entities.PaymentStatus;
import com.example.Exceptions.PaymentNotFoundException;
import com.example.Service.PaymentService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/payments")
@Validated
public class PaymentController {

    private static final Logger logger = LoggerFactory.getLogger(PaymentController.class); // Logger setup

    private final PaymentService paymentService;

    @Autowired
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    // Create or update a Payment
    @PostMapping("/create")
    public ResponseEntity<?> createOrUpdatePayment(@Valid @RequestBody PaymentDTO paymentDTO, BindingResult bindingResult) {
        logger.info("Received request to create or update payment with details: {}", paymentDTO);

        if (bindingResult.hasErrors()) {
            List<String> errorMessages = bindingResult.getAllErrors().stream()
                    .map(error -> error.getDefaultMessage())
                    .collect(Collectors.toList());
            logger.error("Validation failed for paymentDTO: {}", errorMessages);
            return new ResponseEntity<>(errorMessages, HttpStatus.BAD_REQUEST);
        }

        Payment savedPayment = paymentService.saveOrUpdatePayment(paymentDTO);
        logger.info("Payment created/updated successfully with ID: {}", savedPayment.getPaymentId());
        return new ResponseEntity<>(savedPayment, HttpStatus.CREATED);
    }

    // Get all Payments
    @GetMapping
    public ResponseEntity<List<Payment>> getAllPayments() {
        logger.info("Fetching all payments");
        List<Payment> payments = paymentService.getAllPayments();
        logger.info("Retrieved {} payments", payments.size());
        return new ResponseEntity<>(payments, HttpStatus.OK);
    }

    // Get Payment by paymentId
    @GetMapping("/{paymentId}")
    public ResponseEntity<Payment> getPaymentById(@PathVariable Long paymentId) {
        logger.info("Fetching payment with ID: {}", paymentId);
        Optional<Payment> payment = paymentService.getPaymentById(paymentId);
        if (payment.isEmpty()) {
            logger.error("Payment not found for ID: {}", paymentId);
            throw new PaymentNotFoundException("No details found for paymentId: " + paymentId);
        }
        logger.info("Payment found with ID: {}", paymentId);
        return new ResponseEntity<>(payment.get(), HttpStatus.OK);
    }

    // Get Payments by Payment Status
    @GetMapping("/status/{status}")
    public ResponseEntity<List<Payment>> getPaymentsByStatus(@PathVariable String status) {
        logger.info("Fetching payments with status: {}", status);
        PaymentStatus paymentStatus = PaymentStatus.valueOf(status.toUpperCase());
        List<Payment> payments = paymentService.getPaymentsByStatus(paymentStatus);
        logger.info("Retrieved {} payments with status: {}", payments.size(), status);
        return new ResponseEntity<>(payments, HttpStatus.OK);
    }

    // Delete Payment by paymentId
    @DeleteMapping("/{paymentId}")
    public ResponseEntity<Void> deletePayment(@PathVariable Long paymentId) {
        logger.info("Request to delete payment with ID: {}", paymentId);
        paymentService.deletePayment(paymentId);
        logger.info("Payment with ID: {} deleted successfully", paymentId);
        return ResponseEntity.noContent().build();
    }
}
