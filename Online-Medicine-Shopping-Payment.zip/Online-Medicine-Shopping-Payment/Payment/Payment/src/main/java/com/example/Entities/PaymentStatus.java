package com.example.Entities;
public enum PaymentStatus {
    SUCCESS,
    FAILURE,
    PENDING,
    REFUNDED,
    CANCELLED
}
