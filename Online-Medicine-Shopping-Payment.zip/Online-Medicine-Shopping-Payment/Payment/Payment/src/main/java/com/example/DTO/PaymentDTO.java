package com.example.DTO;
import jakarta.validation.constraints.*;

import java.util.Date;

public class PaymentDTO {

   // private Long cartId;
    @NotNull(message = "{payment.amount.notNull}")
    @Positive(message = "{payment.amount.positive}")
    private Double amount;

    @NotBlank(message = "{payment.paymentMethod.notBlank}")
    @Size(max = 50, message = "{payment.paymentMethod.size}")
    private String paymentMethod;

    //@NotNull(message = "{payment.paymentStatus.notNull}")
    private String paymentStatus;

    // No validation for paymentDate since it will be auto-generated
    private Date paymentDate;

    // @NotNull(message = "{payment.customerId.notNull}")
    //private Long customerId;

    // Getters and Setters

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    // public String getPaymentStatus() {
    //    return paymentStatus;
    //}

    //public void setPaymentStatus(String paymentStatus) {
    //  this.paymentStatus = paymentStatus;
    //}

  /* public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }*/

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    @Override
    public String toString() {
        return "PaymentDTO{" +
                "amount=" + amount +
                ", paymentMethod='" + paymentMethod + '\'' +
                ", paymentStatus='" + paymentStatus + '\'' +
                // ", customerId=" + customerId +
                '}';
    }

}